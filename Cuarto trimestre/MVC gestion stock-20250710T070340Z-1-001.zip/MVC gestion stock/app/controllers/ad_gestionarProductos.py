from flask import Blueprint, render_template, request, redirect, url_for, current_app, flash
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
import os 
from app import get_connection

from app.models.product_model import (
     insert_product_with_stock,
     update_product,
     delete_product,
     get_all_product_by_subcategoria,
     get_all_categorias,
     get_categoria_by_id,
     get_subcategorias_by_categorias
     
)



ad_gestionar_bp = Blueprint('ad_gestionar_bp',__name__)
bcrypt = Bcrypt()


@ad_gestionar_bp.route('/')
def index():
    return redirect(url_for('ad_gestionar_bp.listar_categorias'))



@ad_gestionar_bp.route('/categorias')
def listar_categorias():
    connection = get_connection()
    try:
      categorias = get_all_categorias(connection)  
      return render_template('gestion_stock.html', categorias=categorias)
    finally:
        connection.close()


@ad_gestionar_bp.route('/subcategoria/<id_categoria>')
def mostrarSubcategoria(id_categoria):
    connection = get_connection()
    try:
         subcategorias = get_subcategorias_by_categorias(connection, id_categoria)  
         categorias = get_categoria_by_id(connection, id_categoria)  
         return render_template('subcategorias.html', subcategorias=subcategorias, categorias=categorias)

    finally:
        connection.close()


@ad_gestionar_bp.route('/productos/<Id_subcategoria>')
def listaproductos(Id_subcategoria ):
   connection = get_connection()
   try:
        productos = get_all_product_by_subcategoria(connection, Id_subcategoria )
        return render_template('formularioescobas.html', productos=productos, Id_subcategoria=Id_subcategoria)
   finally:
       connection.close()


@ad_gestionar_bp.route('/agregar_product/<Id_subcategoria>', methods=['GET','POST'])
def agregar_product(Id_subcategoria):
    connection = get_connection()
    if request.method == 'POST':
        try:

           cod_Producto = request.form['cod_Producto']
           Referencia = request.form['Referencia']
           marcaProducto = request.form['marcaProducto']
           precioDocena = float(request.form['precio'])
           Subcategoria = request.form['Subcategoria']
           stockMax = 100
           stockMin = 10
           cantidadActual =int(request.form['cantidadActual'])
           estadoProducto = True

    
           insert_product_with_stock(
            connection, 
            cod_Producto,
            Referencia,
            marcaProducto,
            precioDocena,
            Subcategoria,
            stockMax,
            stockMin,
            cantidadActual,
            estadoProducto  
           )
           flash('Producto ingresado exitosamente', 'success')
        
        except Exception as e:
            connection.rollback()
            flash('Error al ingresar el producto' + str(e), 'danger')   
        return redirect(url_for('ad_gestionar_bp.listaproductos',Id_subcategoria=Id_subcategoria))
    try:
        productos = get_all_product_by_subcategoria(connection, Id_subcategoria)
        return render_template('formularioescobas.html', productos=productos, Id_subcategoria=Id_subcategoria)
    finally:
        connection.close()
        

@ad_gestionar_bp.route('/editar_producto/<Id_subcategoria>', methods=['GET','POST'])
def editar_producto(Id_subcategoria):
      connection = get_connection()

      if request.method == 'POST':
         cod_Producto = request.form['cod_Producto']
         Referencia = request.form['Referencia']
         marcaProducto = request.form['marcaProducto']
         precioDocena = float(request.form['precio'])
         Subcategoria = request.form['Subcategoria']
         cantidadActual = int(request.form['cantidadActual'])
         try:
          update_product(connection, cod_Producto, Referencia, marcaProducto, precioDocena, Subcategoria, cantidadActual)   
          flash('Producto editado exitosamente', 'success')
         except Exception as e:
          flash('El producto no ha sidio editado exitosamente:' +str(e), 'danger') 
     
      
         finally:
          connection.close()
    
         return redirect(url_for('ad_gestionar_bp.listaproductos',Id_subcategoria=Id_subcategoria))
  
      else:
          try:
              productos = get_all_product_by_subcategoria(connection, Id_subcategoria)
              return render_template('formularioescobas.html', productos=productos, Id_subcategoria=Id_subcategoria)
          finally:
              connection.close()

@ad_gestionar_bp.route('/eliminar_producto/<cod_Producto>/<Id_subcategoria>',methods=['POST'])
def eliminarProducto(cod_Producto,Id_subcategoria):
    connection = get_connection()

    try:
        delete_product(connection, cod_Producto)
        flash("Producto eliminado correctamente","success")
        return redirect(request.referrer or url_for('ad_gestionar_bp.listaproductos',Id_subcategoria=Id_subcategoria))
    finally:
        connection.close()
  










        

