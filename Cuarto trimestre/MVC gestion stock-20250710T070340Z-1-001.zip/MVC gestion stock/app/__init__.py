from flask import Flask
import pymysql.cursors
from config import Config
from flask import current_app


def create_app():
    app = Flask(__name__)

    app.config.from_object(Config)


    from app.controllers.ad_gestionarProductos import ad_gestionar_bp
    app.register_blueprint(ad_gestionar_bp)

    return app


def get_connection():
    return pymysql.connect(
    host=current_app.config['MYSQL_HOST'],
    user=current_app.config['MYSQL_USER'],
    passwd=current_app.config['MYSQL_PASSWORD'],
    database=current_app.config['MYSQL_DB'],
    cursorclass=pymysql.cursors.DictCursor  


    )