const botonControlStock = document.getElementById("controlstock");

botonControlStock.onclick = () => {
    const filas = document.querySelectorAll("table tbody tr");
    let pocosProductos =[3];

    filas.forEach(fila => {
        const stock = parseInt(fila.children[3].innerText);
        const nombreProducto = fila.children[1].innerText;
       
        fila.style.backgroundColor = "";

   
        if (stock < 5) {
            fila.style.backgroundColor = "rgba(255, 0, 0, 0.2)";
            pocosProductos.push(nombreProducto + " (Muy bajo)");
          } else if (stock < 50){
            fila.style.backgroundColor = "rgba(255, 255, 0, 0.3)";
            pocosProductos.push(nombreProducto + " (Bajo)");
          }
        }); 
      
        if (pocosProductos.length > 0) {
          alert("Productos con bajo stock:\n\n" + pocosProductos.join("\n"));
        } else {
          alert("Todos los productos tienen buen stock.");
        }
      };