const modalEditar = document.getElementById('modalEditar');
modalEditar.addEventListener('show.bs.modal', function(event) {
    const boton = event.relatedTarget;



    document.getElementById('editCodigo').value = boton.getAttribute('data-codigo');
    document.getElementById('editReferencia').value = boton.getAttribute('data-referencia');
    document.getElementById('editMarca').value = boton.getAttribute('data-marca');
    document.getElementById('editStock').value = boton.getAttribute('data-stock');
    document.getElementById('editPrecio').value = boton.getAttribute('data-precio');
});