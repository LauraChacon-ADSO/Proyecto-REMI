# Función para insertar productos nuevos segun su categoria


def insert_product_with_stock(connection, cod_Producto, Referencia, marcaProducto, precioDocena, Subcategoria, stockMax, stockMin, cantidadActual, estadoProducto=True ):
    with connection.cursor() as cursor:
         cursor.execute(
            "INSERT INTO Productos(cod_Producto, Referencia, marcaProducto, precioDocena, Subcategoria) VALUES(%s,%s,%s,%s,%s)",
             (cod_Producto, Referencia, marcaProducto, precioDocena,Subcategoria)
        )  

         cursor.execute("""
        INSERT INTO Stock( stockMax, stockMin, cantidadActual, estadoProducto, productoStock) VALUES(%s,%s,%s,%s,%s)"
         """,( stockMax, stockMin, cantidadActual, estadoProducto,  cod_Producto))
         connection.commit()

# Función para editar producto 

def update_product(connection, cod_Producto, Referencia, marcaProducto, precioDocena, Subcategoria, cantidadActual):
    with connection.cursor() as cursor:
        cursor.execute("""
            UPDATE Productos
            SET Referencia=%s, marcaProducto=%s, precioDocena=%s, Subcategoria=%s
            WHERE cod_Producto=%s
        """, (Referencia, marcaProducto, precioDocena, Subcategoria,cantidadActual))

        cursor.execute("""
            UPDATE Stock
            SET cantidadActual = %s
            WHERE productoStock = %s
        """, (cantidadActual, cod_Producto))

        
        connection.commit()


# Función para eliminar productos 

def delete_product(connection, cod_Producto):
    with connection.cursor() as cursor:
        cursor.execute("UPDATE Productos SET activo = FALSE WHERE cod_Producto = %s", (cod_Producto,))
        connection.commit()


#Funcion para relacionar  productos segun su categoria 

def get_all_product_by_subcategoria(connection, Id_subcategoria):
    with connection.cursor() as cursor:
        cursor.execute("""
              SELECT p.cod_Producto, p.Referencia, p.marcaProducto, p.precioDocena,
                   s.cantidadActual
            FROM   Productos p
            LEFT JOIN Stock s ON s.productoStock = p.cod_Producto
            WHERE p.Subcategoria = %s AND p.activo = TRUE
        """,(Id_subcategoria,))
        return cursor.fetchall()


#Función para para relacionar categoria y su subcategoria 

def get_subcategorias_by_categorias(connection, Id_categoria):
    with connection.cursor() as cursor:
        cursor.execute("""
          SELECT s.Id_subcategoria, s.nombreSub, s.imagensub
          FROM Subcategorias s
          WHERE Categoria = %s
      """,(Id_categoria,))
        return cursor.fetchall()


def get_all_categorias(connection):
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT Id_categoria, nombreCat, imagencat
            FROM Categorias
        """)
        return cursor.fetchall()


def get_categoria_by_id(connection, id_categoria):
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM Categorias WHERE Id_categoria = %s", (id_categoria,))
        return cursor.fetchone()
